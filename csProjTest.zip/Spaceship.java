
public class Spaceship {

    
}
